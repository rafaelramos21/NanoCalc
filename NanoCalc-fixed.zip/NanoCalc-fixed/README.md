# NanoCalc (versão corrigida – Lexer + Parser)

Este pacote foi ajustado para **compilar/rodar de verdade** e ficar coerente com a especificação dos `.md`.

O que foi entregue aqui:

- `src/lexer/` com `buffer.py`, `token.py`, `lexer.py`
  - **maximal munch** (operadores de 2 caracteres antes dos de 1)
  - palavras-chave (`let`, `fn`, `return`, `if`, `else`, `for`, `while`, `in`, `true`, `false`)
  - números (int, dec, científico), strings com escapes
  - comentários `# ...` e `/* ... */` (erro se não fechar)
  - mensagens de erro com **linha/coluna**
- `src/parser/parser.py`
  - parser **recursive descent** compatível com a gramática do `parser_final.md` (subset)
  - validação sintática (erros com linha/coluna)
- `src/main.py`
  - CLI para rodar lexer (`--lex`) ou parser (padrão)

## Como rodar

Dentro da pasta do projeto:

```bash
python -m src.main examples/exemplo.nano --lex
python -m src.main examples/exemplo.nano
```

## Exemplo de entrada

Veja `examples/exemplo.nano`.

## Por que isso era necessário?

O zip original tinha **apenas** `Parcial/lexer.py` e os `.md` descreviam uma estrutura `src/` completa (lexer, parser, etc.).
Aqui eu normalizei o projeto para que:

1) a estrutura exista  
2) o código rode  
3) o comportamento do lexer bata com a especificação

